let btnEdit = document.querySelector("#btnEdit");
btnEdit.addEventListener("click", function(){
    alert("수정 완료!")
})