let btnRegister = document.querySelector("#btnRegister");
btnRegister.addEventListener("click", function(){
    alert("회원가입 완료!");
})




