<br>
<br>


# 1. 로그인,로그아웃 구현
## 1-1. 로그인
### - Log In 버튼을 누르면 alert 창 뜸
### - main 페이지로 이동됨
![](./img/%EB%A1%9C%EA%B7%B8%EC%9D%B8.png)

![](./img/%EB%A1%9C%EA%B7%B8%EC%9D%B8%EC%99%84%EB%A3%8C%EC%8B%9Calert%EC%B0%BD.png)

![](./img/%EB%A1%9C%EA%B7%B8%EC%9D%B8%EC%99%84%EB%A3%8C%ED%99%94%EB%A9%B4.png)

<br>

## 1-2. 로그아웃
### - 아래 상단 navigation bar 에서 로그아웃 버튼을 누르면 main 페이지로 이동

![](./img/%EB%A1%9C%EA%B7%B8%EC%95%84%EC%9A%B4_%EB%B2%84%ED%8A%BC.png)
<br>
![](./img/%EB%A9%94%EC%9D%B8%ED%99%94%EB%A9%B4.jpg)


<br>

# 2. 회원가입, 수정
## 2-1. 회원가입
### - SIGN UP 버튼을 누르면 alert 창 뜸
### - 회원가입 완료되면 로그인 페이지로 이동됨
![](./img/%ED%9A%8C%EC%9B%90%EA%B0%80%EC%9E%85.png)


![](./img/%ED%9A%8C%EC%9B%90%EA%B0%80%EC%9E%85%EC%99%84%EB%A3%8C%EC%8B%9Calert%EC%B0%BD.png)

<br>

## 2-2. 수정
### - 아래 상단 "정보 수정" 버튼 클릭시 정보 수정 페이지 화면 이동
![](./img/%EC%A0%95%EB%B3%B4%EC%88%98%EC%A0%95_%EB%B2%84%ED%8A%BC%EB%B3%B4%EB%9D%BC%EC%83%89.png)
![](./img/%ED%9A%8C%EC%9B%90%EC%A0%95%EB%B3%B4%EC%88%98%EC%A0%95.png)


<br>

# 3. 즐겨찾기
### - 아래 "즐겨찾는 장소" 클릭시 즐겨찾기 전체 목록 페이지로 이동
### - 즐겨찾기 전체 목록 페이지
![](./img/%EC%A6%90%EA%B2%A8%EC%B0%BE%EB%8A%94%EC%9E%A5%EC%86%8C_%EB%B2%84%ED%8A%BC%EC%83%89%EC%B9%A0.png)
![](./img/%EC%A6%90%EA%B2%A8%EC%B0%BE%EB%8A%94%EC%9E%A5%EC%86%8C.png)


<br>

# 4. 게시판
### - 상단의 navigation bar 의 게시판 클릭시 아래 페이지로 이동
![](./img/%EA%B2%8C%EC%8B%9C%ED%8C%90.png) 

<br>

# 5. 관광지 검색
### - "부산 명지" 검색 결과 화면
![](./img/%EA%B2%80%EC%83%89%EA%B8%B0%EB%8A%A5.png)

### - 왼쪽 검색 리스트 중 하나를 클릭하면 상세 페이지로 이동됨
### - 상세 페이지의 즐겨찾기 버튼을 클릭시에 "즐겨찾기 추가 완료!"라는 alert 창 활성

![](./img/%EA%B2%80%EC%83%89%EB%A6%AC%EC%8A%A4%ED%8A%B8.png)
![](./img/%EB%94%94%ED%85%8C%EC%9D%BC%ED%8E%98%EC%9D%B4%EC%A7%80.png)
![](./img/%EC%A6%90%EA%B2%A8%EC%B0%BE%EA%B8%B0%EB%B2%84%ED%8A%BC%ED%81%B4%EB%A6%AD%EC%8B%9Calert%EC%B0%BD.png)
<br>


