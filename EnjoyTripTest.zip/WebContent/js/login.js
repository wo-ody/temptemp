let btnLogin = document.querySelector("#btnLogin");
btnLogin.addEventListener("click", function(){
    alert("로그인 완료!")
})